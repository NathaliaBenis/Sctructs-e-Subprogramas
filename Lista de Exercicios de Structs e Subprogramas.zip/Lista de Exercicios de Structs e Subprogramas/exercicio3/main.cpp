#include <stdio.h>


int calcularAnosParaCrescimento(double popA, double taxaA, double popB, double taxaB) {
    int anos = 0;


    while (popA < popB) {
        popA += popA * taxaA;
        popB += popB * taxaB;
        anos++;
    }

    return anos;
}

int main() {
    double populacaoA = 90000000;
    double populacaoB = 200000000;
    double taxaCrescimentoA = 0.03;
    double taxaCrescimentoB = 0.015;


    int anosNecessarios = calcularAnosParaCrescimento(populacaoA, taxaCrescimentoA, populacaoB, taxaCrescimentoB);


    printf("Numeros necesserios para que a populacao do pais A ultrapasse ou seja igual a do pais B: %d\n", anosNecessarios);

    return 0;
}
