#include <stdio.h>


double fahrenheitParaCelsius(double fahrenheit) {
    return 5.0 / 9.0 * (fahrenheit - 32);
}

int main() {
    double fahrenheit, celsius;


    printf("A conversao de Fahrenheit para Celsius sera:\n");
    printf("Fahrenheit\tCelsius\n");
    printf("-----------------------\n");


    for (fahrenheit = 0; fahrenheit <= 100; fahrenheit++) {
        celsius = fahrenheitParaCelsius(fahrenheit);
        printf("%.1f\t\t%.2f\n", fahrenheit, celsius);
    }

    return 0;
}

