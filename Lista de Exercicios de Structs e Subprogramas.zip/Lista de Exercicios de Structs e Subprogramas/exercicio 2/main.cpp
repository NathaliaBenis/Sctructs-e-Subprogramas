#include <stdio.h>


int encontrarMaior(int a, int b, int c) {
    int maior = a;

    if (b > maior) {
        maior = b;
    }
    if (c > maior) {
        maior = c;
    }

    return maior;
}

int main() {
    int valor1, valor2, valor3, maior;


    printf("Informe o primeiro valor: ");
    scanf("%d", &valor1);

    printf("Informe o segundo valor: ");
    scanf("%d", &valor2);

    printf("Informe o terceiro valor: ");
    scanf("%d", &valor3);


    maior = encontrarMaior(valor1, valor2, valor3);

    printf("O maior valor entre %d, %d e %d sera %d.\n", valor1, valor2, valor3, maior);

    return 0;
}
