#include <stdio.h>
#include <string.h>

#define MAX_ALUNOS 50
#define MAX_NOME 100


typedef struct {
    int matricula;
    char nome[MAX_NOME];
} Aluno;

int main() {
    Aluno alunos[MAX_ALUNOS];
    int i, num_alunos;

    printf("Informe o numero de alunos (maximo %d): ", MAX_ALUNOS);
    scanf("%d", &num_alunos);


    if (num_alunos < 1 || num_alunos > MAX_ALUNOS) {
        printf("Numero invalido de alunos. O programa sera encerrado.\n");
        return 1;
    }


    for (i = 0; i < num_alunos; i++) {
        printf("Informe a matricula do aluno %d: ", i + 1);
        scanf("%d", &alunos[i].matricula);

        while (getchar() != '\n');

        printf("Informe o nome do aluno %d (maximo %d caracteres): ", i + 1, MAX_NOME - 1);
        fgets(alunos[i].nome, MAX_NOME, stdin);

        alunos[i].nome[strcspn(alunos[i].nome, "\n")] = '\0';
    }


    printf("\nDados dos alunos:\n");
    for (i = 0; i < num_alunos; i++) {
        printf("Matricula: %d\n", alunos[i].matricula);
        printf("Nome: %s\n", alunos[i].nome);
        printf("\n");
    }

    return 0;
}
